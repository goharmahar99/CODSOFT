
let screen = document.querySelector(".input");
let buttons = document.querySelectorAll('button');
let string = '';

buttons.forEach(button=>{
	button.addEventListener('click',(x)=>{
		if(x.target.innerHTML === '='){
			screen.value = String(eval(screen.value));
	      }
	      else if(x.target.innerHTML === 'AC'){
              screen.value = string;
	      }
	      else if(x.target.innerHTML === 'Del'){
             screen.value = screen.value.slice(0,-1);
	      }
      
       else{
           screen.value += x.target.innerHTML;
  
	    }
  });
});







